#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <fcntl.h>
#include <unistd.h>
#include <math.h>
#include <string.h>
#include <errno.h>
#include <pthread.h>


int block_count, number_of_threads = 5, blocks_per_thread;
int balance, block_size;
float f_block_per_thread, total_file_size;
double global_bytes_read = 0;
char *file_name;
float tt = 0.0;
int file_pointer[15];


unsigned int xorbuf(unsigned int *buffer, int size) {
    unsigned int result = 0;
    for (int i = 0; i < size; i++) {
        result ^= buffer[i];
    }
    return result;
}

void checker(int argc, char* argv[]){

    if(argc<4){
        printf("Usage: ./threaded <filename> <block_size> <block_count> [optional: <number_of_threads> (default 5)]\n");
        printf("Example: ./threaded input.txt 50 200\nExample: ./threaded input.txt 50 200 12\n");
        exit(1);
    }

    if(atoi(argv[2])<=0){
        printf("Block size cannot be a string or an integer <= 0\n");
        exit(1);
    }
    if(atoi(argv[3])<=0){
        printf("Block count cannot be a string or an integer <= 0\n");
        exit(1);
    }
    if(argv[4]!=NULL && atoi(argv[4])<=0){
        printf("Number of threads cannot be a string or an integer <= 0\n");
        exit(1);
    }

}


void * reader(void * arg){

    
    long tid = (long)arg;
    int bytes_read;
    double total_bytes_read = 0;
    int buffer[block_size];
    int individual_count;
    unsigned int result = 0;

    int fd = open(file_name,O_RDONLY);
    if(fd==-1){
        printf("Error: %s\n",strerror(errno));
        exit(1);
    }
    
    if(tid==number_of_threads-1)
        individual_count = balance+blocks_per_thread;
    else
        individual_count = blocks_per_thread;

    // int ll = lseek(fd,(tid*blocks_per_thread*block_size),SEEK_SET);
    // if(ll==-1){
    //     printf("%s\n",strerror(errno));
    //     exit(1);
    // }

    clock_t start = clock();
    while(individual_count!=0 && (bytes_read = read(file_pointer[tid],buffer,block_size))>0){
        
        result ^= xorbuf(buffer,ceil(bytes_read/4));
        individual_count-=1;
        total_bytes_read += bytes_read;
    }
    clock_t end = clock();
    global_bytes_read += total_bytes_read;
    tt += (float)(end-start)/CLOCKS_PER_SEC;
    printf("[Thread %d read]: %.f bytes in %fs\n",tid,total_bytes_read,(float)(end-start)/CLOCKS_PER_SEC);
    close(file_pointer[tid]);
    
    pthread_exit((void *)result);

}

int main(int argc, char * argv[]){

    checker(argc,argv);
    
    pthread_t *fr;
    long i;
    file_name = argv[1];
    block_size = atoi(argv[2]);
    block_count = atoi(argv[3]);

    if(argv[4]!=NULL)
        number_of_threads = atoi(argv[4]);
    else
        printf("No threads arg supplied. Defaulting to 5 threads.\n");

    // Get the total file size
    int fp = open(file_name,O_RDONLY);
    if(fp==-1){
        printf("Error: %s",errno);
    }
    total_file_size = lseek(fp,0,SEEK_END);
    close(fp);
    // printf("FS = %f\n",total_file_size);
    if(block_count*(float)block_size < total_file_size){
        f_block_per_thread = ((float)block_count/(float)number_of_threads);
        blocks_per_thread = floor(f_block_per_thread);
    }
    else{
        float inter = (total_file_size/(float)block_size);
        // printf("Inter = %f\n",inter);
        f_block_per_thread = inter/(float)number_of_threads;
        // printf("FBT = %f\n",f_block_per_thread);
        blocks_per_thread = ceil(f_block_per_thread);
    }

    printf("Avg blocks_per_thread = %d\n",blocks_per_thread);
    
    float sub = fabs(f_block_per_thread-blocks_per_thread);
    // printf("sub = %f\n",sub);
    balance = (int)round(sub*(float)number_of_threads);
    
    fr = (pthread_t *) malloc(sizeof(pthread_t)*number_of_threads);
    
    for(i=0;i<number_of_threads;i++){
        fp = open(file_name,O_RDONLY);
        lseek(fp,(i*blocks_per_thread*block_size),SEEK_SET);
        file_pointer[i] = fp;
    }

    clock_t starting = clock();
    struct timespec spec,endspec;
    clock_gettime(CLOCK_REALTIME,&spec);

    for(i=0;i<number_of_threads;i++){
        pthread_create(&fr[i],NULL,reader,(void*)i);
        if(i==number_of_threads-1)
            block_count-=(balance+blocks_per_thread);
        else
            block_count-=(int)(blocks_per_thread);
    }

    

    clock_t mid1 = clock();
    void * result = NULL;
    unsigned int ret = 0;
    clock_t mid2 = clock();
    for(i=0;i<number_of_threads;i++){
        pthread_join(fr[i],&result);
        ret ^= (unsigned int)result;
    }
    clock_gettime(CLOCK_REALTIME,&endspec);
    clock_t ending = clock();

    long seconds = endspec.tv_sec - spec.tv_sec;
    long nanoseconds = endspec.tv_nsec - spec.tv_nsec;
    double elapsed = seconds + nanoseconds*1e-9;

    printf("\nTime = %f\n",(float)(ending-starting)/CLOCKS_PER_SEC);
    printf("Total bytes read = %f\n",global_bytes_read);
    printf("Speed = %.2f MB/s\n",(global_bytes_read/1048576.0)/elapsed);
    printf("XOR %08x\n",ret);
    return 0;
}           