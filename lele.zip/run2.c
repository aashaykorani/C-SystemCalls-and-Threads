#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <fcntl.h>
#include <unistd.h>
#include <math.h>
#include <string.h>
#include <errno.h>

unsigned int xorbuf(unsigned int *buffer, int size) {
    unsigned int result = 0;
    for (int i = 0; i < size; i++) {
        result ^= buffer[i];
    }
    return result;
}

void checker(int argc, char* argv[]){

    if(argc<2 || argc>3){
        printf("Usage: ./run2 <block_count> [optional:<time_to_run> (default 6s)]\n");
        printf("Example: ./run2 50\nExample: ./run2 50 6\n");
        exit(1);
    }
    if(atoi(argv[1])<=0){
        printf("Block size cannot be a string or an integer <= 0\n");
        exit(1);
    }
    if(argv[2]!=NULL && (atoi(argv[2])<5 || atoi(argv[2])>15)){
        printf("Reasonable time is between 5 to 15 seconds.\n");
        exit(1);
    }
}

void reader(char * argv[]){

    double input_block_size = atoi(argv[1]);
    input_block_size = ceil(input_block_size/4);
    int block_size = input_block_size;
    int block_count = 0;
    int bytes_read;
    double total_bytes_read = 0;
    int buffer[block_size];
    float rtime = 6.0;
    if(argv[2]!=NULL)
        rtime = atoi(argv[2]);
    else
        printf("No time arg supplied. Defaulting to %.fs.\n",rtime);
    clock_t start;



    int fd = open("ubuntu-21.04-desktop-amd64.iso",O_RDONLY);
    if(fd==-1){
        printf("This program needs the file \'ubuntu-21.04-desktop-amd64.iso\' in the current directory.\n");
        printf("%s\n",strerror(errno));
        exit(1);
    }
    
    float time_taken;

    start = clock();
    again:while((time_taken = (float)(clock() - start) / CLOCKS_PER_SEC) < rtime && ((bytes_read = read(fd,buffer,block_size*4)) > 0)){
        
        block_count += 1;
        total_bytes_read += bytes_read;

    }
    if(bytes_read == 0 && time_taken<rtime){
        lseek(fd,0,SEEK_SET);
        goto again;
    }

    // printf("Number of blocks read = %d\n",block_count);
    // printf("Time taken = %f\n",time_taken);
    printf("File size read = %.f bytes\nBlock size = %d\nTime taken = %f seconds.\n",total_bytes_read,atoi(argv[1]),time_taken);
    printf("Reading Speed = %.2f MB/s\n",(total_bytes_read/1048576.0)/time_taken);
    close(fd);

}


int main(int argc, char* argv[]){

    checker(argc, argv);
    reader(argv);

    return 0;
}